#!/bin/sh
docker pull jeremiedevelops/easy-masm:latest
docker run --rm -v ./src:/easy-masm/src/ jeremiedevelops/easy-masm:latest sh run.sh $1
