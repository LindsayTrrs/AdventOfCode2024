# Some Helpful Tips

* For VSCode users, check out the [MASM Extension](https://marketplace.visualstudio.com/items?itemName=blindtiger.masm) to add syntax highlighting for MASM files
* For Vim users, type `:set ft=masm` on .asm files to get MASM syntax highlighting!
    * or add `let asmsyntax="masm"` to your `.vimrc`
