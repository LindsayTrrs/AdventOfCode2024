echo Please run: 'cd ..' in the terminal and try again
